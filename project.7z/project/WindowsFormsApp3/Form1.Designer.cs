﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.fireW1 = new System.Windows.Forms.PictureBox();
            this.fireW2 = new System.Windows.Forms.PictureBox();
            this.fireW3 = new System.Windows.Forms.PictureBox();
            this.fireW4 = new System.Windows.Forms.PictureBox();
            this.fireX1 = new System.Windows.Forms.PictureBox();
            this.fireX2 = new System.Windows.Forms.PictureBox();
            this.fireX3 = new System.Windows.Forms.PictureBox();
            this.fireX4 = new System.Windows.Forms.PictureBox();
            this.fireY1 = new System.Windows.Forms.PictureBox();
            this.fireY2 = new System.Windows.Forms.PictureBox();
            this.fireY3 = new System.Windows.Forms.PictureBox();
            this.fireY4 = new System.Windows.Forms.PictureBox();
            this.fireZ1 = new System.Windows.Forms.PictureBox();
            this.fireZ2 = new System.Windows.Forms.PictureBox();
            this.fireZ3 = new System.Windows.Forms.PictureBox();
            this.fireZ4 = new System.Windows.Forms.PictureBox();
            this.fireA1 = new System.Windows.Forms.PictureBox();
            this.fireB1 = new System.Windows.Forms.PictureBox();
            this.fireC1 = new System.Windows.Forms.PictureBox();
            this.fireD1 = new System.Windows.Forms.PictureBox();
            this.fireA2 = new System.Windows.Forms.PictureBox();
            this.fireB2 = new System.Windows.Forms.PictureBox();
            this.fireC2 = new System.Windows.Forms.PictureBox();
            this.fireD2 = new System.Windows.Forms.PictureBox();
            this.fireA3 = new System.Windows.Forms.PictureBox();
            this.fireB3 = new System.Windows.Forms.PictureBox();
            this.fireC3 = new System.Windows.Forms.PictureBox();
            this.fireD3 = new System.Windows.Forms.PictureBox();
            this.fireA4 = new System.Windows.Forms.PictureBox();
            this.fireB4 = new System.Windows.Forms.PictureBox();
            this.fireC4 = new System.Windows.Forms.PictureBox();
            this.fireD4 = new System.Windows.Forms.PictureBox();
            this.w1 = new System.Windows.Forms.Button();
            this.w2 = new System.Windows.Forms.Button();
            this.W3 = new System.Windows.Forms.Button();
            this.w4 = new System.Windows.Forms.Button();
            this.x1 = new System.Windows.Forms.Button();
            this.x2 = new System.Windows.Forms.Button();
            this.missW1 = new System.Windows.Forms.PictureBox();
            this.missW2 = new System.Windows.Forms.PictureBox();
            this.missW3 = new System.Windows.Forms.PictureBox();
            this.missW4 = new System.Windows.Forms.PictureBox();
            this.missX1 = new System.Windows.Forms.PictureBox();
            this.missX2 = new System.Windows.Forms.PictureBox();
            this.missX3 = new System.Windows.Forms.PictureBox();
            this.missX4 = new System.Windows.Forms.PictureBox();
            this.missY1 = new System.Windows.Forms.PictureBox();
            this.missY2 = new System.Windows.Forms.PictureBox();
            this.missY3 = new System.Windows.Forms.PictureBox();
            this.missY4 = new System.Windows.Forms.PictureBox();
            this.missZ1 = new System.Windows.Forms.PictureBox();
            this.missA3 = new System.Windows.Forms.PictureBox();
            this.missA2 = new System.Windows.Forms.PictureBox();
            this.missA1 = new System.Windows.Forms.PictureBox();
            this.missZ4 = new System.Windows.Forms.PictureBox();
            this.missZ3 = new System.Windows.Forms.PictureBox();
            this.missZ2 = new System.Windows.Forms.PictureBox();
            this.y1 = new System.Windows.Forms.Button();
            this.x4 = new System.Windows.Forms.Button();
            this.x3 = new System.Windows.Forms.Button();
            this.y2 = new System.Windows.Forms.Button();
            this.y3 = new System.Windows.Forms.Button();
            this.y4 = new System.Windows.Forms.Button();
            this.z1 = new System.Windows.Forms.Button();
            this.z2 = new System.Windows.Forms.Button();
            this.z3 = new System.Windows.Forms.Button();
            this.z4 = new System.Windows.Forms.Button();
            this.a1 = new System.Windows.Forms.Button();
            this.missD1 = new System.Windows.Forms.PictureBox();
            this.missC4 = new System.Windows.Forms.PictureBox();
            this.missC3 = new System.Windows.Forms.PictureBox();
            this.missC2 = new System.Windows.Forms.PictureBox();
            this.missC1 = new System.Windows.Forms.PictureBox();
            this.missB4 = new System.Windows.Forms.PictureBox();
            this.missB3 = new System.Windows.Forms.PictureBox();
            this.missB2 = new System.Windows.Forms.PictureBox();
            this.missB1 = new System.Windows.Forms.PictureBox();
            this.missA4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.missD3 = new System.Windows.Forms.PictureBox();
            this.missD2 = new System.Windows.Forms.PictureBox();
            this.b1 = new System.Windows.Forms.Button();
            this.a4 = new System.Windows.Forms.Button();
            this.a3 = new System.Windows.Forms.Button();
            this.a2 = new System.Windows.Forms.Button();
            this.c2 = new System.Windows.Forms.Button();
            this.c1 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.d3 = new System.Windows.Forms.Button();
            this.d2 = new System.Windows.Forms.Button();
            this.d1 = new System.Windows.Forms.Button();
            this.c4 = new System.Windows.Forms.Button();
            this.c3 = new System.Windows.Forms.Button();
            this.d4 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.fireW1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireW2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireW3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireW4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireX1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireX2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireX3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireX4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireY1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireY2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireY3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireY4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireZ1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireZ2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireZ3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireZ4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireA1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireB1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireC1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireD1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireA2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireB2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireC2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireD2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireA3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireB3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireC3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireD3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireA4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireB4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireC4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireD4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missW1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missW2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missW3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missW4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missX1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missX2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missX3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missX4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missY1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missY2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missY3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missY4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missZ1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missA3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missA2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missA1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missZ4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missZ3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missZ2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missD1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missC4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missC3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missC2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missC1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missB4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missB3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missB2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missB1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missA4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missD3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.missD2)).BeginInit();
            this.SuspendLayout();
            // 
            // fireW1
            // 
            this.fireW1.Image = ((System.Drawing.Image)(resources.GetObject("fireW1.Image")));
            this.fireW1.Location = new System.Drawing.Point(70, 166);
            this.fireW1.Margin = new System.Windows.Forms.Padding(2);
            this.fireW1.Name = "fireW1";
            this.fireW1.Size = new System.Drawing.Size(54, 49);
            this.fireW1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireW1.TabIndex = 1;
            this.fireW1.TabStop = false;
            this.fireW1.Visible = false;
            this.fireW1.Click += new System.EventHandler(this.press);
            // 
            // fireW2
            // 
            this.fireW2.Image = ((System.Drawing.Image)(resources.GetObject("fireW2.Image")));
            this.fireW2.Location = new System.Drawing.Point(132, 166);
            this.fireW2.Margin = new System.Windows.Forms.Padding(2);
            this.fireW2.Name = "fireW2";
            this.fireW2.Size = new System.Drawing.Size(54, 49);
            this.fireW2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireW2.TabIndex = 2;
            this.fireW2.TabStop = false;
            this.fireW2.Visible = false;
            this.fireW2.Click += new System.EventHandler(this.press);
            // 
            // fireW3
            // 
            this.fireW3.Image = ((System.Drawing.Image)(resources.GetObject("fireW3.Image")));
            this.fireW3.Location = new System.Drawing.Point(196, 166);
            this.fireW3.Margin = new System.Windows.Forms.Padding(2);
            this.fireW3.Name = "fireW3";
            this.fireW3.Size = new System.Drawing.Size(54, 49);
            this.fireW3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireW3.TabIndex = 3;
            this.fireW3.TabStop = false;
            this.fireW3.Visible = false;
            this.fireW3.Click += new System.EventHandler(this.press);
            // 
            // fireW4
            // 
            this.fireW4.Image = ((System.Drawing.Image)(resources.GetObject("fireW4.Image")));
            this.fireW4.Location = new System.Drawing.Point(259, 166);
            this.fireW4.Margin = new System.Windows.Forms.Padding(2);
            this.fireW4.Name = "fireW4";
            this.fireW4.Size = new System.Drawing.Size(54, 49);
            this.fireW4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireW4.TabIndex = 4;
            this.fireW4.TabStop = false;
            this.fireW4.Visible = false;
            this.fireW4.Click += new System.EventHandler(this.press);
            // 
            // fireX1
            // 
            this.fireX1.Image = ((System.Drawing.Image)(resources.GetObject("fireX1.Image")));
            this.fireX1.Location = new System.Drawing.Point(70, 226);
            this.fireX1.Margin = new System.Windows.Forms.Padding(2);
            this.fireX1.Name = "fireX1";
            this.fireX1.Size = new System.Drawing.Size(54, 50);
            this.fireX1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireX1.TabIndex = 5;
            this.fireX1.TabStop = false;
            this.fireX1.Visible = false;
            this.fireX1.Click += new System.EventHandler(this.press);
            // 
            // fireX2
            // 
            this.fireX2.Image = ((System.Drawing.Image)(resources.GetObject("fireX2.Image")));
            this.fireX2.Location = new System.Drawing.Point(132, 226);
            this.fireX2.Margin = new System.Windows.Forms.Padding(2);
            this.fireX2.Name = "fireX2";
            this.fireX2.Size = new System.Drawing.Size(54, 50);
            this.fireX2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireX2.TabIndex = 6;
            this.fireX2.TabStop = false;
            this.fireX2.Visible = false;
            this.fireX2.Click += new System.EventHandler(this.press);
            // 
            // fireX3
            // 
            this.fireX3.Image = ((System.Drawing.Image)(resources.GetObject("fireX3.Image")));
            this.fireX3.Location = new System.Drawing.Point(196, 226);
            this.fireX3.Margin = new System.Windows.Forms.Padding(2);
            this.fireX3.Name = "fireX3";
            this.fireX3.Size = new System.Drawing.Size(54, 50);
            this.fireX3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireX3.TabIndex = 7;
            this.fireX3.TabStop = false;
            this.fireX3.Visible = false;
            this.fireX3.Click += new System.EventHandler(this.press);
            // 
            // fireX4
            // 
            this.fireX4.Image = ((System.Drawing.Image)(resources.GetObject("fireX4.Image")));
            this.fireX4.Location = new System.Drawing.Point(259, 226);
            this.fireX4.Margin = new System.Windows.Forms.Padding(2);
            this.fireX4.Name = "fireX4";
            this.fireX4.Size = new System.Drawing.Size(54, 50);
            this.fireX4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireX4.TabIndex = 8;
            this.fireX4.TabStop = false;
            this.fireX4.Visible = false;
            this.fireX4.Click += new System.EventHandler(this.press);
            // 
            // fireY1
            // 
            this.fireY1.Image = ((System.Drawing.Image)(resources.GetObject("fireY1.Image")));
            this.fireY1.Location = new System.Drawing.Point(70, 279);
            this.fireY1.Margin = new System.Windows.Forms.Padding(2);
            this.fireY1.Name = "fireY1";
            this.fireY1.Size = new System.Drawing.Size(54, 53);
            this.fireY1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireY1.TabIndex = 9;
            this.fireY1.TabStop = false;
            this.fireY1.Visible = false;
            this.fireY1.Click += new System.EventHandler(this.press);
            // 
            // fireY2
            // 
            this.fireY2.Image = ((System.Drawing.Image)(resources.GetObject("fireY2.Image")));
            this.fireY2.Location = new System.Drawing.Point(132, 278);
            this.fireY2.Margin = new System.Windows.Forms.Padding(2);
            this.fireY2.Name = "fireY2";
            this.fireY2.Size = new System.Drawing.Size(54, 53);
            this.fireY2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireY2.TabIndex = 10;
            this.fireY2.TabStop = false;
            this.fireY2.Visible = false;
            this.fireY2.Click += new System.EventHandler(this.press);
            // 
            // fireY3
            // 
            this.fireY3.Image = ((System.Drawing.Image)(resources.GetObject("fireY3.Image")));
            this.fireY3.Location = new System.Drawing.Point(196, 279);
            this.fireY3.Margin = new System.Windows.Forms.Padding(2);
            this.fireY3.Name = "fireY3";
            this.fireY3.Size = new System.Drawing.Size(54, 53);
            this.fireY3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireY3.TabIndex = 11;
            this.fireY3.TabStop = false;
            this.fireY3.Visible = false;
            this.fireY3.Click += new System.EventHandler(this.press);
            // 
            // fireY4
            // 
            this.fireY4.Image = ((System.Drawing.Image)(resources.GetObject("fireY4.Image")));
            this.fireY4.Location = new System.Drawing.Point(259, 279);
            this.fireY4.Margin = new System.Windows.Forms.Padding(2);
            this.fireY4.Name = "fireY4";
            this.fireY4.Size = new System.Drawing.Size(54, 53);
            this.fireY4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireY4.TabIndex = 12;
            this.fireY4.TabStop = false;
            this.fireY4.Visible = false;
            this.fireY4.Click += new System.EventHandler(this.press);
            // 
            // fireZ1
            // 
            this.fireZ1.Image = ((System.Drawing.Image)(resources.GetObject("fireZ1.Image")));
            this.fireZ1.Location = new System.Drawing.Point(70, 334);
            this.fireZ1.Margin = new System.Windows.Forms.Padding(2);
            this.fireZ1.Name = "fireZ1";
            this.fireZ1.Size = new System.Drawing.Size(54, 54);
            this.fireZ1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireZ1.TabIndex = 13;
            this.fireZ1.TabStop = false;
            this.fireZ1.Visible = false;
            this.fireZ1.Click += new System.EventHandler(this.press);
            // 
            // fireZ2
            // 
            this.fireZ2.Image = ((System.Drawing.Image)(resources.GetObject("fireZ2.Image")));
            this.fireZ2.Location = new System.Drawing.Point(132, 334);
            this.fireZ2.Margin = new System.Windows.Forms.Padding(2);
            this.fireZ2.Name = "fireZ2";
            this.fireZ2.Size = new System.Drawing.Size(54, 54);
            this.fireZ2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireZ2.TabIndex = 14;
            this.fireZ2.TabStop = false;
            this.fireZ2.Visible = false;
            this.fireZ2.Click += new System.EventHandler(this.press);
            // 
            // fireZ3
            // 
            this.fireZ3.Image = ((System.Drawing.Image)(resources.GetObject("fireZ3.Image")));
            this.fireZ3.Location = new System.Drawing.Point(196, 334);
            this.fireZ3.Margin = new System.Windows.Forms.Padding(2);
            this.fireZ3.Name = "fireZ3";
            this.fireZ3.Size = new System.Drawing.Size(54, 54);
            this.fireZ3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireZ3.TabIndex = 15;
            this.fireZ3.TabStop = false;
            this.fireZ3.Visible = false;
            this.fireZ3.Click += new System.EventHandler(this.press);
            // 
            // fireZ4
            // 
            this.fireZ4.Image = ((System.Drawing.Image)(resources.GetObject("fireZ4.Image")));
            this.fireZ4.Location = new System.Drawing.Point(259, 334);
            this.fireZ4.Margin = new System.Windows.Forms.Padding(2);
            this.fireZ4.Name = "fireZ4";
            this.fireZ4.Size = new System.Drawing.Size(54, 54);
            this.fireZ4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireZ4.TabIndex = 16;
            this.fireZ4.TabStop = false;
            this.fireZ4.Visible = false;
            this.fireZ4.Click += new System.EventHandler(this.press);
            // 
            // fireA1
            // 
            this.fireA1.Image = ((System.Drawing.Image)(resources.GetObject("fireA1.Image")));
            this.fireA1.Location = new System.Drawing.Point(408, 166);
            this.fireA1.Margin = new System.Windows.Forms.Padding(2);
            this.fireA1.Name = "fireA1";
            this.fireA1.Size = new System.Drawing.Size(54, 49);
            this.fireA1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireA1.TabIndex = 17;
            this.fireA1.TabStop = false;
            this.fireA1.Visible = false;
            // 
            // fireB1
            // 
            this.fireB1.Image = ((System.Drawing.Image)(resources.GetObject("fireB1.Image")));
            this.fireB1.Location = new System.Drawing.Point(408, 226);
            this.fireB1.Margin = new System.Windows.Forms.Padding(2);
            this.fireB1.Name = "fireB1";
            this.fireB1.Size = new System.Drawing.Size(54, 50);
            this.fireB1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireB1.TabIndex = 18;
            this.fireB1.TabStop = false;
            this.fireB1.Visible = false;
            // 
            // fireC1
            // 
            this.fireC1.Image = ((System.Drawing.Image)(resources.GetObject("fireC1.Image")));
            this.fireC1.Location = new System.Drawing.Point(408, 278);
            this.fireC1.Margin = new System.Windows.Forms.Padding(2);
            this.fireC1.Name = "fireC1";
            this.fireC1.Size = new System.Drawing.Size(54, 53);
            this.fireC1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireC1.TabIndex = 19;
            this.fireC1.TabStop = false;
            this.fireC1.Visible = false;
            // 
            // fireD1
            // 
            this.fireD1.Image = ((System.Drawing.Image)(resources.GetObject("fireD1.Image")));
            this.fireD1.Location = new System.Drawing.Point(408, 339);
            this.fireD1.Margin = new System.Windows.Forms.Padding(2);
            this.fireD1.Name = "fireD1";
            this.fireD1.Size = new System.Drawing.Size(54, 50);
            this.fireD1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireD1.TabIndex = 20;
            this.fireD1.TabStop = false;
            this.fireD1.Visible = false;
            // 
            // fireA2
            // 
            this.fireA2.Image = ((System.Drawing.Image)(resources.GetObject("fireA2.Image")));
            this.fireA2.Location = new System.Drawing.Point(471, 166);
            this.fireA2.Margin = new System.Windows.Forms.Padding(2);
            this.fireA2.Name = "fireA2";
            this.fireA2.Size = new System.Drawing.Size(54, 49);
            this.fireA2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireA2.TabIndex = 21;
            this.fireA2.TabStop = false;
            this.fireA2.Visible = false;
            // 
            // fireB2
            // 
            this.fireB2.Image = ((System.Drawing.Image)(resources.GetObject("fireB2.Image")));
            this.fireB2.Location = new System.Drawing.Point(471, 226);
            this.fireB2.Margin = new System.Windows.Forms.Padding(2);
            this.fireB2.Name = "fireB2";
            this.fireB2.Size = new System.Drawing.Size(54, 50);
            this.fireB2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireB2.TabIndex = 22;
            this.fireB2.TabStop = false;
            this.fireB2.Visible = false;
            // 
            // fireC2
            // 
            this.fireC2.Image = ((System.Drawing.Image)(resources.GetObject("fireC2.Image")));
            this.fireC2.Location = new System.Drawing.Point(471, 279);
            this.fireC2.Margin = new System.Windows.Forms.Padding(2);
            this.fireC2.Name = "fireC2";
            this.fireC2.Size = new System.Drawing.Size(54, 53);
            this.fireC2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireC2.TabIndex = 23;
            this.fireC2.TabStop = false;
            this.fireC2.Visible = false;
            // 
            // fireD2
            // 
            this.fireD2.Image = ((System.Drawing.Image)(resources.GetObject("fireD2.Image")));
            this.fireD2.Location = new System.Drawing.Point(471, 334);
            this.fireD2.Margin = new System.Windows.Forms.Padding(2);
            this.fireD2.Name = "fireD2";
            this.fireD2.Size = new System.Drawing.Size(54, 54);
            this.fireD2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireD2.TabIndex = 24;
            this.fireD2.TabStop = false;
            this.fireD2.Visible = false;
            // 
            // fireA3
            // 
            this.fireA3.Image = ((System.Drawing.Image)(resources.GetObject("fireA3.Image")));
            this.fireA3.Location = new System.Drawing.Point(534, 166);
            this.fireA3.Margin = new System.Windows.Forms.Padding(2);
            this.fireA3.Name = "fireA3";
            this.fireA3.Size = new System.Drawing.Size(54, 49);
            this.fireA3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireA3.TabIndex = 25;
            this.fireA3.TabStop = false;
            this.fireA3.Visible = false;
            this.fireA3.Click += new System.EventHandler(this.fireA3_Click);
            // 
            // fireB3
            // 
            this.fireB3.Image = ((System.Drawing.Image)(resources.GetObject("fireB3.Image")));
            this.fireB3.Location = new System.Drawing.Point(534, 226);
            this.fireB3.Margin = new System.Windows.Forms.Padding(2);
            this.fireB3.Name = "fireB3";
            this.fireB3.Size = new System.Drawing.Size(54, 50);
            this.fireB3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireB3.TabIndex = 26;
            this.fireB3.TabStop = false;
            this.fireB3.Visible = false;
            // 
            // fireC3
            // 
            this.fireC3.Image = ((System.Drawing.Image)(resources.GetObject("fireC3.Image")));
            this.fireC3.Location = new System.Drawing.Point(534, 278);
            this.fireC3.Margin = new System.Windows.Forms.Padding(2);
            this.fireC3.Name = "fireC3";
            this.fireC3.Size = new System.Drawing.Size(54, 53);
            this.fireC3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireC3.TabIndex = 27;
            this.fireC3.TabStop = false;
            this.fireC3.Visible = false;
            // 
            // fireD3
            // 
            this.fireD3.Image = ((System.Drawing.Image)(resources.GetObject("fireD3.Image")));
            this.fireD3.Location = new System.Drawing.Point(534, 339);
            this.fireD3.Margin = new System.Windows.Forms.Padding(2);
            this.fireD3.Name = "fireD3";
            this.fireD3.Size = new System.Drawing.Size(54, 50);
            this.fireD3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireD3.TabIndex = 28;
            this.fireD3.TabStop = false;
            this.fireD3.Visible = false;
            // 
            // fireA4
            // 
            this.fireA4.Image = ((System.Drawing.Image)(resources.GetObject("fireA4.Image")));
            this.fireA4.Location = new System.Drawing.Point(598, 167);
            this.fireA4.Margin = new System.Windows.Forms.Padding(2);
            this.fireA4.Name = "fireA4";
            this.fireA4.Size = new System.Drawing.Size(50, 49);
            this.fireA4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireA4.TabIndex = 29;
            this.fireA4.TabStop = false;
            this.fireA4.Visible = false;
            // 
            // fireB4
            // 
            this.fireB4.Image = ((System.Drawing.Image)(resources.GetObject("fireB4.Image")));
            this.fireB4.Location = new System.Drawing.Point(598, 226);
            this.fireB4.Margin = new System.Windows.Forms.Padding(2);
            this.fireB4.Name = "fireB4";
            this.fireB4.Size = new System.Drawing.Size(54, 50);
            this.fireB4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireB4.TabIndex = 30;
            this.fireB4.TabStop = false;
            this.fireB4.Visible = false;
            this.fireB4.Click += new System.EventHandler(this.pictureBox30_Click);
            // 
            // fireC4
            // 
            this.fireC4.Image = ((System.Drawing.Image)(resources.GetObject("fireC4.Image")));
            this.fireC4.Location = new System.Drawing.Point(598, 279);
            this.fireC4.Margin = new System.Windows.Forms.Padding(2);
            this.fireC4.Name = "fireC4";
            this.fireC4.Size = new System.Drawing.Size(54, 53);
            this.fireC4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireC4.TabIndex = 31;
            this.fireC4.TabStop = false;
            this.fireC4.Visible = false;
            // 
            // fireD4
            // 
            this.fireD4.Image = ((System.Drawing.Image)(resources.GetObject("fireD4.Image")));
            this.fireD4.Location = new System.Drawing.Point(598, 339);
            this.fireD4.Margin = new System.Windows.Forms.Padding(2);
            this.fireD4.Name = "fireD4";
            this.fireD4.Size = new System.Drawing.Size(54, 50);
            this.fireD4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fireD4.TabIndex = 32;
            this.fireD4.TabStop = false;
            this.fireD4.Visible = false;
            this.fireD4.Click += new System.EventHandler(this.fireD4_Click);
            // 
            // w1
            // 
            this.w1.Location = new System.Drawing.Point(70, 166);
            this.w1.Margin = new System.Windows.Forms.Padding(2);
            this.w1.Name = "w1";
            this.w1.Size = new System.Drawing.Size(54, 50);
            this.w1.TabIndex = 33;
            this.w1.Text = "W1";
            this.w1.UseVisualStyleBackColor = true;
            this.w1.Click += new System.EventHandler(this.press);
            // 
            // w2
            // 
            this.w2.Location = new System.Drawing.Point(132, 166);
            this.w2.Margin = new System.Windows.Forms.Padding(2);
            this.w2.Name = "w2";
            this.w2.Size = new System.Drawing.Size(54, 50);
            this.w2.TabIndex = 34;
            this.w2.Text = "W2";
            this.w2.UseVisualStyleBackColor = true;
            this.w2.Click += new System.EventHandler(this.press);
            // 
            // W3
            // 
            this.W3.BackColor = System.Drawing.SystemColors.Control;
            this.W3.Cursor = System.Windows.Forms.Cursors.Default;
            this.W3.Location = new System.Drawing.Point(196, 166);
            this.W3.Margin = new System.Windows.Forms.Padding(2);
            this.W3.Name = "W3";
            this.W3.Size = new System.Drawing.Size(54, 50);
            this.W3.TabIndex = 35;
            this.W3.Text = "W3";
            this.W3.UseVisualStyleBackColor = false;
            this.W3.Click += new System.EventHandler(this.press);
            // 
            // w4
            // 
            this.w4.Location = new System.Drawing.Point(259, 166);
            this.w4.Margin = new System.Windows.Forms.Padding(2);
            this.w4.Name = "w4";
            this.w4.Size = new System.Drawing.Size(54, 50);
            this.w4.TabIndex = 36;
            this.w4.Text = "W4";
            this.w4.UseVisualStyleBackColor = true;
            this.w4.Click += new System.EventHandler(this.press);
            // 
            // x1
            // 
            this.x1.Location = new System.Drawing.Point(70, 226);
            this.x1.Margin = new System.Windows.Forms.Padding(2);
            this.x1.Name = "x1";
            this.x1.Size = new System.Drawing.Size(54, 50);
            this.x1.TabIndex = 37;
            this.x1.Text = "X1";
            this.x1.UseVisualStyleBackColor = true;
            this.x1.Click += new System.EventHandler(this.press);
            // 
            // x2
            // 
            this.x2.Location = new System.Drawing.Point(132, 226);
            this.x2.Margin = new System.Windows.Forms.Padding(2);
            this.x2.Name = "x2";
            this.x2.Size = new System.Drawing.Size(54, 50);
            this.x2.TabIndex = 38;
            this.x2.Text = "X2";
            this.x2.UseVisualStyleBackColor = true;
            this.x2.Click += new System.EventHandler(this.press);
            // 
            // missW1
            // 
            this.missW1.Image = ((System.Drawing.Image)(resources.GetObject("missW1.Image")));
            this.missW1.Location = new System.Drawing.Point(70, 166);
            this.missW1.Margin = new System.Windows.Forms.Padding(2);
            this.missW1.Name = "missW1";
            this.missW1.Size = new System.Drawing.Size(54, 50);
            this.missW1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missW1.TabIndex = 39;
            this.missW1.TabStop = false;
            this.missW1.Visible = false;
            this.missW1.Click += new System.EventHandler(this.press);
            // 
            // missW2
            // 
            this.missW2.Image = ((System.Drawing.Image)(resources.GetObject("missW2.Image")));
            this.missW2.Location = new System.Drawing.Point(132, 166);
            this.missW2.Margin = new System.Windows.Forms.Padding(2);
            this.missW2.Name = "missW2";
            this.missW2.Size = new System.Drawing.Size(54, 50);
            this.missW2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missW2.TabIndex = 40;
            this.missW2.TabStop = false;
            this.missW2.Visible = false;
            this.missW2.Click += new System.EventHandler(this.press);
            // 
            // missW3
            // 
            this.missW3.Image = ((System.Drawing.Image)(resources.GetObject("missW3.Image")));
            this.missW3.Location = new System.Drawing.Point(196, 166);
            this.missW3.Margin = new System.Windows.Forms.Padding(2);
            this.missW3.Name = "missW3";
            this.missW3.Size = new System.Drawing.Size(54, 50);
            this.missW3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missW3.TabIndex = 41;
            this.missW3.TabStop = false;
            this.missW3.Visible = false;
            this.missW3.Click += new System.EventHandler(this.press);
            // 
            // missW4
            // 
            this.missW4.Image = ((System.Drawing.Image)(resources.GetObject("missW4.Image")));
            this.missW4.Location = new System.Drawing.Point(259, 166);
            this.missW4.Margin = new System.Windows.Forms.Padding(2);
            this.missW4.Name = "missW4";
            this.missW4.Size = new System.Drawing.Size(54, 50);
            this.missW4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missW4.TabIndex = 42;
            this.missW4.TabStop = false;
            this.missW4.Visible = false;
            this.missW4.Click += new System.EventHandler(this.press);
            // 
            // missX1
            // 
            this.missX1.Image = ((System.Drawing.Image)(resources.GetObject("missX1.Image")));
            this.missX1.Location = new System.Drawing.Point(70, 226);
            this.missX1.Margin = new System.Windows.Forms.Padding(2);
            this.missX1.Name = "missX1";
            this.missX1.Size = new System.Drawing.Size(54, 50);
            this.missX1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missX1.TabIndex = 43;
            this.missX1.TabStop = false;
            this.missX1.Visible = false;
            this.missX1.Click += new System.EventHandler(this.press);
            // 
            // missX2
            // 
            this.missX2.Image = ((System.Drawing.Image)(resources.GetObject("missX2.Image")));
            this.missX2.Location = new System.Drawing.Point(132, 226);
            this.missX2.Margin = new System.Windows.Forms.Padding(2);
            this.missX2.Name = "missX2";
            this.missX2.Size = new System.Drawing.Size(54, 50);
            this.missX2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missX2.TabIndex = 44;
            this.missX2.TabStop = false;
            this.missX2.Visible = false;
            this.missX2.Click += new System.EventHandler(this.press);
            // 
            // missX3
            // 
            this.missX3.Image = ((System.Drawing.Image)(resources.GetObject("missX3.Image")));
            this.missX3.Location = new System.Drawing.Point(196, 226);
            this.missX3.Margin = new System.Windows.Forms.Padding(2);
            this.missX3.Name = "missX3";
            this.missX3.Size = new System.Drawing.Size(54, 50);
            this.missX3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missX3.TabIndex = 45;
            this.missX3.TabStop = false;
            this.missX3.Visible = false;
            this.missX3.Click += new System.EventHandler(this.press);
            // 
            // missX4
            // 
            this.missX4.Image = ((System.Drawing.Image)(resources.GetObject("missX4.Image")));
            this.missX4.Location = new System.Drawing.Point(259, 226);
            this.missX4.Margin = new System.Windows.Forms.Padding(2);
            this.missX4.Name = "missX4";
            this.missX4.Size = new System.Drawing.Size(54, 50);
            this.missX4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missX4.TabIndex = 46;
            this.missX4.TabStop = false;
            this.missX4.Visible = false;
            this.missX4.Click += new System.EventHandler(this.press);
            // 
            // missY1
            // 
            this.missY1.Image = ((System.Drawing.Image)(resources.GetObject("missY1.Image")));
            this.missY1.Location = new System.Drawing.Point(70, 282);
            this.missY1.Margin = new System.Windows.Forms.Padding(2);
            this.missY1.Name = "missY1";
            this.missY1.Size = new System.Drawing.Size(54, 50);
            this.missY1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missY1.TabIndex = 47;
            this.missY1.TabStop = false;
            this.missY1.Visible = false;
            this.missY1.Click += new System.EventHandler(this.press);
            // 
            // missY2
            // 
            this.missY2.Image = ((System.Drawing.Image)(resources.GetObject("missY2.Image")));
            this.missY2.Location = new System.Drawing.Point(132, 282);
            this.missY2.Margin = new System.Windows.Forms.Padding(2);
            this.missY2.Name = "missY2";
            this.missY2.Size = new System.Drawing.Size(54, 50);
            this.missY2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missY2.TabIndex = 48;
            this.missY2.TabStop = false;
            this.missY2.Visible = false;
            this.missY2.Click += new System.EventHandler(this.press);
            // 
            // missY3
            // 
            this.missY3.Image = ((System.Drawing.Image)(resources.GetObject("missY3.Image")));
            this.missY3.Location = new System.Drawing.Point(196, 282);
            this.missY3.Margin = new System.Windows.Forms.Padding(2);
            this.missY3.Name = "missY3";
            this.missY3.Size = new System.Drawing.Size(54, 50);
            this.missY3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missY3.TabIndex = 49;
            this.missY3.TabStop = false;
            this.missY3.Visible = false;
            this.missY3.Click += new System.EventHandler(this.press);
            // 
            // missY4
            // 
            this.missY4.Image = ((System.Drawing.Image)(resources.GetObject("missY4.Image")));
            this.missY4.Location = new System.Drawing.Point(259, 282);
            this.missY4.Margin = new System.Windows.Forms.Padding(2);
            this.missY4.Name = "missY4";
            this.missY4.Size = new System.Drawing.Size(54, 50);
            this.missY4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missY4.TabIndex = 50;
            this.missY4.TabStop = false;
            this.missY4.Visible = false;
            this.missY4.Click += new System.EventHandler(this.press);
            // 
            // missZ1
            // 
            this.missZ1.Image = ((System.Drawing.Image)(resources.GetObject("missZ1.Image")));
            this.missZ1.Location = new System.Drawing.Point(70, 339);
            this.missZ1.Margin = new System.Windows.Forms.Padding(2);
            this.missZ1.Name = "missZ1";
            this.missZ1.Size = new System.Drawing.Size(54, 50);
            this.missZ1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missZ1.TabIndex = 51;
            this.missZ1.TabStop = false;
            this.missZ1.Visible = false;
            this.missZ1.Click += new System.EventHandler(this.press);
            // 
            // missA3
            // 
            this.missA3.Image = ((System.Drawing.Image)(resources.GetObject("missA3.Image")));
            this.missA3.Location = new System.Drawing.Point(534, 166);
            this.missA3.Margin = new System.Windows.Forms.Padding(2);
            this.missA3.Name = "missA3";
            this.missA3.Size = new System.Drawing.Size(54, 50);
            this.missA3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missA3.TabIndex = 52;
            this.missA3.TabStop = false;
            this.missA3.Visible = false;
            // 
            // missA2
            // 
            this.missA2.Image = ((System.Drawing.Image)(resources.GetObject("missA2.Image")));
            this.missA2.Location = new System.Drawing.Point(471, 166);
            this.missA2.Margin = new System.Windows.Forms.Padding(2);
            this.missA2.Name = "missA2";
            this.missA2.Size = new System.Drawing.Size(54, 50);
            this.missA2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missA2.TabIndex = 53;
            this.missA2.TabStop = false;
            this.missA2.Visible = false;
            // 
            // missA1
            // 
            this.missA1.Image = ((System.Drawing.Image)(resources.GetObject("missA1.Image")));
            this.missA1.Location = new System.Drawing.Point(408, 166);
            this.missA1.Margin = new System.Windows.Forms.Padding(2);
            this.missA1.Name = "missA1";
            this.missA1.Size = new System.Drawing.Size(54, 50);
            this.missA1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missA1.TabIndex = 54;
            this.missA1.TabStop = false;
            this.missA1.Visible = false;
            // 
            // missZ4
            // 
            this.missZ4.Image = ((System.Drawing.Image)(resources.GetObject("missZ4.Image")));
            this.missZ4.Location = new System.Drawing.Point(259, 339);
            this.missZ4.Margin = new System.Windows.Forms.Padding(2);
            this.missZ4.Name = "missZ4";
            this.missZ4.Size = new System.Drawing.Size(54, 50);
            this.missZ4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missZ4.TabIndex = 55;
            this.missZ4.TabStop = false;
            this.missZ4.Visible = false;
            this.missZ4.Click += new System.EventHandler(this.press);
            // 
            // missZ3
            // 
            this.missZ3.Image = ((System.Drawing.Image)(resources.GetObject("missZ3.Image")));
            this.missZ3.Location = new System.Drawing.Point(196, 339);
            this.missZ3.Margin = new System.Windows.Forms.Padding(2);
            this.missZ3.Name = "missZ3";
            this.missZ3.Size = new System.Drawing.Size(54, 50);
            this.missZ3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missZ3.TabIndex = 56;
            this.missZ3.TabStop = false;
            this.missZ3.Visible = false;
            this.missZ3.Click += new System.EventHandler(this.press);
            // 
            // missZ2
            // 
            this.missZ2.Image = ((System.Drawing.Image)(resources.GetObject("missZ2.Image")));
            this.missZ2.Location = new System.Drawing.Point(132, 339);
            this.missZ2.Margin = new System.Windows.Forms.Padding(2);
            this.missZ2.Name = "missZ2";
            this.missZ2.Size = new System.Drawing.Size(54, 50);
            this.missZ2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missZ2.TabIndex = 57;
            this.missZ2.TabStop = false;
            this.missZ2.Visible = false;
            this.missZ2.Click += new System.EventHandler(this.press);
            // 
            // y1
            // 
            this.y1.Location = new System.Drawing.Point(70, 278);
            this.y1.Margin = new System.Windows.Forms.Padding(2);
            this.y1.Name = "y1";
            this.y1.Size = new System.Drawing.Size(54, 50);
            this.y1.TabIndex = 70;
            this.y1.Text = "Y1";
            this.y1.UseVisualStyleBackColor = true;
            this.y1.Click += new System.EventHandler(this.press);
            // 
            // x4
            // 
            this.x4.Location = new System.Drawing.Point(259, 226);
            this.x4.Margin = new System.Windows.Forms.Padding(2);
            this.x4.Name = "x4";
            this.x4.Size = new System.Drawing.Size(54, 50);
            this.x4.TabIndex = 71;
            this.x4.Text = "X4";
            this.x4.UseVisualStyleBackColor = true;
            this.x4.Click += new System.EventHandler(this.press);
            // 
            // x3
            // 
            this.x3.Location = new System.Drawing.Point(196, 226);
            this.x3.Margin = new System.Windows.Forms.Padding(2);
            this.x3.Name = "x3";
            this.x3.Size = new System.Drawing.Size(54, 50);
            this.x3.TabIndex = 72;
            this.x3.Text = "X3";
            this.x3.UseVisualStyleBackColor = true;
            this.x3.Click += new System.EventHandler(this.press);
            // 
            // y2
            // 
            this.y2.Location = new System.Drawing.Point(132, 282);
            this.y2.Margin = new System.Windows.Forms.Padding(2);
            this.y2.Name = "y2";
            this.y2.Size = new System.Drawing.Size(54, 50);
            this.y2.TabIndex = 73;
            this.y2.Text = "Y2";
            this.y2.UseVisualStyleBackColor = true;
            this.y2.Click += new System.EventHandler(this.press);
            // 
            // y3
            // 
            this.y3.Location = new System.Drawing.Point(196, 282);
            this.y3.Margin = new System.Windows.Forms.Padding(2);
            this.y3.Name = "y3";
            this.y3.Size = new System.Drawing.Size(54, 50);
            this.y3.TabIndex = 74;
            this.y3.Text = "Y3";
            this.y3.UseVisualStyleBackColor = true;
            this.y3.Click += new System.EventHandler(this.press);
            // 
            // y4
            // 
            this.y4.Location = new System.Drawing.Point(259, 282);
            this.y4.Margin = new System.Windows.Forms.Padding(2);
            this.y4.Name = "y4";
            this.y4.Size = new System.Drawing.Size(54, 50);
            this.y4.TabIndex = 75;
            this.y4.Text = "Y4";
            this.y4.UseVisualStyleBackColor = true;
            this.y4.Click += new System.EventHandler(this.press);
            // 
            // z1
            // 
            this.z1.Location = new System.Drawing.Point(70, 339);
            this.z1.Margin = new System.Windows.Forms.Padding(2);
            this.z1.Name = "z1";
            this.z1.Size = new System.Drawing.Size(54, 50);
            this.z1.TabIndex = 76;
            this.z1.Text = "Z1";
            this.z1.UseVisualStyleBackColor = true;
            this.z1.Click += new System.EventHandler(this.press);
            // 
            // z2
            // 
            this.z2.Location = new System.Drawing.Point(132, 339);
            this.z2.Margin = new System.Windows.Forms.Padding(2);
            this.z2.Name = "z2";
            this.z2.Size = new System.Drawing.Size(54, 50);
            this.z2.TabIndex = 77;
            this.z2.Text = "Z2";
            this.z2.UseVisualStyleBackColor = true;
            this.z2.Click += new System.EventHandler(this.press);
            // 
            // z3
            // 
            this.z3.Location = new System.Drawing.Point(196, 339);
            this.z3.Margin = new System.Windows.Forms.Padding(2);
            this.z3.Name = "z3";
            this.z3.Size = new System.Drawing.Size(54, 50);
            this.z3.TabIndex = 78;
            this.z3.Text = "Z3";
            this.z3.UseVisualStyleBackColor = true;
            this.z3.Click += new System.EventHandler(this.press);
            // 
            // z4
            // 
            this.z4.Location = new System.Drawing.Point(259, 339);
            this.z4.Margin = new System.Windows.Forms.Padding(2);
            this.z4.Name = "z4";
            this.z4.Size = new System.Drawing.Size(54, 50);
            this.z4.TabIndex = 79;
            this.z4.Text = "Z4";
            this.z4.UseVisualStyleBackColor = true;
            this.z4.Click += new System.EventHandler(this.press);
            // 
            // a1
            // 
            this.a1.Location = new System.Drawing.Point(408, 167);
            this.a1.Margin = new System.Windows.Forms.Padding(2);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(54, 50);
            this.a1.TabIndex = 80;
            this.a1.Text = "A1";
            this.a1.UseVisualStyleBackColor = true;
            this.a1.Click += new System.EventHandler(this.a1_Click);
            // 
            // missD1
            // 
            this.missD1.Image = ((System.Drawing.Image)(resources.GetObject("missD1.Image")));
            this.missD1.Location = new System.Drawing.Point(408, 339);
            this.missD1.Margin = new System.Windows.Forms.Padding(2);
            this.missD1.Name = "missD1";
            this.missD1.Size = new System.Drawing.Size(54, 50);
            this.missD1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missD1.TabIndex = 81;
            this.missD1.TabStop = false;
            this.missD1.Visible = false;
            // 
            // missC4
            // 
            this.missC4.Image = ((System.Drawing.Image)(resources.GetObject("missC4.Image")));
            this.missC4.Location = new System.Drawing.Point(598, 282);
            this.missC4.Margin = new System.Windows.Forms.Padding(2);
            this.missC4.Name = "missC4";
            this.missC4.Size = new System.Drawing.Size(54, 50);
            this.missC4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missC4.TabIndex = 82;
            this.missC4.TabStop = false;
            this.missC4.Visible = false;
            // 
            // missC3
            // 
            this.missC3.Image = ((System.Drawing.Image)(resources.GetObject("missC3.Image")));
            this.missC3.Location = new System.Drawing.Point(534, 282);
            this.missC3.Margin = new System.Windows.Forms.Padding(2);
            this.missC3.Name = "missC3";
            this.missC3.Size = new System.Drawing.Size(54, 50);
            this.missC3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missC3.TabIndex = 83;
            this.missC3.TabStop = false;
            this.missC3.Visible = false;
            // 
            // missC2
            // 
            this.missC2.Image = ((System.Drawing.Image)(resources.GetObject("missC2.Image")));
            this.missC2.Location = new System.Drawing.Point(471, 282);
            this.missC2.Margin = new System.Windows.Forms.Padding(2);
            this.missC2.Name = "missC2";
            this.missC2.Size = new System.Drawing.Size(54, 50);
            this.missC2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missC2.TabIndex = 84;
            this.missC2.TabStop = false;
            this.missC2.Visible = false;
            // 
            // missC1
            // 
            this.missC1.Image = ((System.Drawing.Image)(resources.GetObject("missC1.Image")));
            this.missC1.Location = new System.Drawing.Point(412, 282);
            this.missC1.Margin = new System.Windows.Forms.Padding(2);
            this.missC1.Name = "missC1";
            this.missC1.Size = new System.Drawing.Size(54, 50);
            this.missC1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missC1.TabIndex = 85;
            this.missC1.TabStop = false;
            this.missC1.Visible = false;
            // 
            // missB4
            // 
            this.missB4.Image = ((System.Drawing.Image)(resources.GetObject("missB4.Image")));
            this.missB4.Location = new System.Drawing.Point(598, 226);
            this.missB4.Margin = new System.Windows.Forms.Padding(2);
            this.missB4.Name = "missB4";
            this.missB4.Size = new System.Drawing.Size(54, 50);
            this.missB4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missB4.TabIndex = 86;
            this.missB4.TabStop = false;
            this.missB4.Visible = false;
            // 
            // missB3
            // 
            this.missB3.Image = ((System.Drawing.Image)(resources.GetObject("missB3.Image")));
            this.missB3.Location = new System.Drawing.Point(534, 226);
            this.missB3.Margin = new System.Windows.Forms.Padding(2);
            this.missB3.Name = "missB3";
            this.missB3.Size = new System.Drawing.Size(54, 50);
            this.missB3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missB3.TabIndex = 87;
            this.missB3.TabStop = false;
            this.missB3.Visible = false;
            // 
            // missB2
            // 
            this.missB2.Image = ((System.Drawing.Image)(resources.GetObject("missB2.Image")));
            this.missB2.Location = new System.Drawing.Point(471, 226);
            this.missB2.Margin = new System.Windows.Forms.Padding(2);
            this.missB2.Name = "missB2";
            this.missB2.Size = new System.Drawing.Size(54, 50);
            this.missB2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missB2.TabIndex = 88;
            this.missB2.TabStop = false;
            this.missB2.Visible = false;
            // 
            // missB1
            // 
            this.missB1.Image = ((System.Drawing.Image)(resources.GetObject("missB1.Image")));
            this.missB1.Location = new System.Drawing.Point(412, 226);
            this.missB1.Margin = new System.Windows.Forms.Padding(2);
            this.missB1.Name = "missB1";
            this.missB1.Size = new System.Drawing.Size(54, 50);
            this.missB1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missB1.TabIndex = 89;
            this.missB1.TabStop = false;
            this.missB1.Visible = false;
            // 
            // missA4
            // 
            this.missA4.Image = ((System.Drawing.Image)(resources.GetObject("missA4.Image")));
            this.missA4.Location = new System.Drawing.Point(598, 166);
            this.missA4.Margin = new System.Windows.Forms.Padding(2);
            this.missA4.Name = "missA4";
            this.missA4.Size = new System.Drawing.Size(54, 50);
            this.missA4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missA4.TabIndex = 90;
            this.missA4.TabStop = false;
            this.missA4.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(598, 339);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(54, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 93;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // missD3
            // 
            this.missD3.Image = ((System.Drawing.Image)(resources.GetObject("missD3.Image")));
            this.missD3.Location = new System.Drawing.Point(534, 339);
            this.missD3.Margin = new System.Windows.Forms.Padding(2);
            this.missD3.Name = "missD3";
            this.missD3.Size = new System.Drawing.Size(54, 50);
            this.missD3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missD3.TabIndex = 94;
            this.missD3.TabStop = false;
            this.missD3.Visible = false;
            // 
            // missD2
            // 
            this.missD2.Image = ((System.Drawing.Image)(resources.GetObject("missD2.Image")));
            this.missD2.Location = new System.Drawing.Point(471, 339);
            this.missD2.Margin = new System.Windows.Forms.Padding(2);
            this.missD2.Name = "missD2";
            this.missD2.Size = new System.Drawing.Size(54, 50);
            this.missD2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.missD2.TabIndex = 95;
            this.missD2.TabStop = false;
            this.missD2.Visible = false;
            // 
            // b1
            // 
            this.b1.Location = new System.Drawing.Point(408, 226);
            this.b1.Margin = new System.Windows.Forms.Padding(2);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(54, 50);
            this.b1.TabIndex = 96;
            this.b1.Text = "B1";
            this.b1.UseVisualStyleBackColor = true;
            // 
            // a4
            // 
            this.a4.Location = new System.Drawing.Point(598, 166);
            this.a4.Margin = new System.Windows.Forms.Padding(2);
            this.a4.Name = "a4";
            this.a4.Size = new System.Drawing.Size(54, 50);
            this.a4.TabIndex = 97;
            this.a4.Text = "A4";
            this.a4.UseVisualStyleBackColor = true;
            // 
            // a3
            // 
            this.a3.Location = new System.Drawing.Point(534, 166);
            this.a3.Margin = new System.Windows.Forms.Padding(2);
            this.a3.Name = "a3";
            this.a3.Size = new System.Drawing.Size(54, 50);
            this.a3.TabIndex = 98;
            this.a3.Text = "A3";
            this.a3.UseVisualStyleBackColor = true;
            // 
            // a2
            // 
            this.a2.Location = new System.Drawing.Point(471, 166);
            this.a2.Margin = new System.Windows.Forms.Padding(2);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(54, 50);
            this.a2.TabIndex = 99;
            this.a2.Text = "A2";
            this.a2.UseVisualStyleBackColor = true;
            // 
            // c2
            // 
            this.c2.Location = new System.Drawing.Point(471, 282);
            this.c2.Margin = new System.Windows.Forms.Padding(2);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(54, 50);
            this.c2.TabIndex = 100;
            this.c2.Text = "C2";
            this.c2.UseVisualStyleBackColor = true;
            // 
            // c1
            // 
            this.c1.Location = new System.Drawing.Point(408, 282);
            this.c1.Margin = new System.Windows.Forms.Padding(2);
            this.c1.Name = "c1";
            this.c1.Size = new System.Drawing.Size(54, 50);
            this.c1.TabIndex = 101;
            this.c1.Text = "C1";
            this.c1.UseVisualStyleBackColor = true;
            // 
            // b4
            // 
            this.b4.Location = new System.Drawing.Point(598, 226);
            this.b4.Margin = new System.Windows.Forms.Padding(2);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(54, 50);
            this.b4.TabIndex = 102;
            this.b4.Text = "B4";
            this.b4.UseVisualStyleBackColor = true;
            // 
            // b3
            // 
            this.b3.Location = new System.Drawing.Point(534, 226);
            this.b3.Margin = new System.Windows.Forms.Padding(2);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(54, 50);
            this.b3.TabIndex = 103;
            this.b3.Text = "B3";
            this.b3.UseVisualStyleBackColor = true;
            // 
            // b2
            // 
            this.b2.Location = new System.Drawing.Point(471, 226);
            this.b2.Margin = new System.Windows.Forms.Padding(2);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(54, 50);
            this.b2.TabIndex = 104;
            this.b2.Text = "B2";
            this.b2.UseVisualStyleBackColor = true;
            // 
            // d3
            // 
            this.d3.Location = new System.Drawing.Point(534, 339);
            this.d3.Margin = new System.Windows.Forms.Padding(2);
            this.d3.Name = "d3";
            this.d3.Size = new System.Drawing.Size(54, 50);
            this.d3.TabIndex = 105;
            this.d3.Text = "D3";
            this.d3.UseVisualStyleBackColor = true;
            // 
            // d2
            // 
            this.d2.Location = new System.Drawing.Point(471, 339);
            this.d2.Margin = new System.Windows.Forms.Padding(2);
            this.d2.Name = "d2";
            this.d2.Size = new System.Drawing.Size(54, 50);
            this.d2.TabIndex = 106;
            this.d2.Text = "D2";
            this.d2.UseVisualStyleBackColor = true;
            // 
            // d1
            // 
            this.d1.Location = new System.Drawing.Point(408, 339);
            this.d1.Margin = new System.Windows.Forms.Padding(2);
            this.d1.Name = "d1";
            this.d1.Size = new System.Drawing.Size(54, 50);
            this.d1.TabIndex = 107;
            this.d1.Text = "D1";
            this.d1.UseVisualStyleBackColor = true;
            // 
            // c4
            // 
            this.c4.Location = new System.Drawing.Point(598, 282);
            this.c4.Margin = new System.Windows.Forms.Padding(2);
            this.c4.Name = "c4";
            this.c4.Size = new System.Drawing.Size(54, 50);
            this.c4.TabIndex = 108;
            this.c4.Text = "C4";
            this.c4.UseVisualStyleBackColor = true;
            // 
            // c3
            // 
            this.c3.Location = new System.Drawing.Point(534, 282);
            this.c3.Margin = new System.Windows.Forms.Padding(2);
            this.c3.Name = "c3";
            this.c3.Size = new System.Drawing.Size(54, 50);
            this.c3.TabIndex = 109;
            this.c3.Text = "C3";
            this.c3.UseVisualStyleBackColor = true;
            // 
            // d4
            // 
            this.d4.Location = new System.Drawing.Point(598, 339);
            this.d4.Margin = new System.Windows.Forms.Padding(2);
            this.d4.Name = "d4";
            this.d4.Size = new System.Drawing.Size(54, 50);
            this.d4.TabIndex = 110;
            this.d4.Text = "D4";
            this.d4.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Items.AddRange(new object[] {
            "A1",
            "A2",
            "A3",
            "A4",
            "B1",
            "B2",
            "B3",
            "B4",
            "C1",
            "C2",
            "C3",
            "C4",
            "D1",
            "D2",
            "D3",
            "D4"});
            this.listBox1.Location = new System.Drawing.Point(70, 24);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(124, 52);
            this.listBox1.TabIndex = 111;
            this.listBox1.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 434);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.d4);
            this.Controls.Add(this.c3);
            this.Controls.Add(this.c4);
            this.Controls.Add(this.d1);
            this.Controls.Add(this.d2);
            this.Controls.Add(this.d3);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.c1);
            this.Controls.Add(this.c2);
            this.Controls.Add(this.a2);
            this.Controls.Add(this.a3);
            this.Controls.Add(this.a4);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.missD2);
            this.Controls.Add(this.missD3);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.missA4);
            this.Controls.Add(this.missB1);
            this.Controls.Add(this.missB2);
            this.Controls.Add(this.missB3);
            this.Controls.Add(this.missB4);
            this.Controls.Add(this.missC1);
            this.Controls.Add(this.missC2);
            this.Controls.Add(this.missC3);
            this.Controls.Add(this.missC4);
            this.Controls.Add(this.missD1);
            this.Controls.Add(this.a1);
            this.Controls.Add(this.z4);
            this.Controls.Add(this.z3);
            this.Controls.Add(this.z2);
            this.Controls.Add(this.z1);
            this.Controls.Add(this.y4);
            this.Controls.Add(this.y3);
            this.Controls.Add(this.y2);
            this.Controls.Add(this.x3);
            this.Controls.Add(this.x4);
            this.Controls.Add(this.y1);
            this.Controls.Add(this.missZ2);
            this.Controls.Add(this.missZ3);
            this.Controls.Add(this.missZ4);
            this.Controls.Add(this.missA1);
            this.Controls.Add(this.missA2);
            this.Controls.Add(this.missA3);
            this.Controls.Add(this.missZ1);
            this.Controls.Add(this.missY4);
            this.Controls.Add(this.missY3);
            this.Controls.Add(this.missY2);
            this.Controls.Add(this.missY1);
            this.Controls.Add(this.missX4);
            this.Controls.Add(this.missX3);
            this.Controls.Add(this.missX2);
            this.Controls.Add(this.missX1);
            this.Controls.Add(this.missW4);
            this.Controls.Add(this.missW3);
            this.Controls.Add(this.missW2);
            this.Controls.Add(this.missW1);
            this.Controls.Add(this.x2);
            this.Controls.Add(this.x1);
            this.Controls.Add(this.w4);
            this.Controls.Add(this.W3);
            this.Controls.Add(this.w2);
            this.Controls.Add(this.w1);
            this.Controls.Add(this.fireD4);
            this.Controls.Add(this.fireC4);
            this.Controls.Add(this.fireB4);
            this.Controls.Add(this.fireA4);
            this.Controls.Add(this.fireD3);
            this.Controls.Add(this.fireC3);
            this.Controls.Add(this.fireB3);
            this.Controls.Add(this.fireA3);
            this.Controls.Add(this.fireD2);
            this.Controls.Add(this.fireC2);
            this.Controls.Add(this.fireB2);
            this.Controls.Add(this.fireA2);
            this.Controls.Add(this.fireD1);
            this.Controls.Add(this.fireC1);
            this.Controls.Add(this.fireB1);
            this.Controls.Add(this.fireA1);
            this.Controls.Add(this.fireZ4);
            this.Controls.Add(this.fireZ3);
            this.Controls.Add(this.fireZ2);
            this.Controls.Add(this.fireZ1);
            this.Controls.Add(this.fireY4);
            this.Controls.Add(this.fireY3);
            this.Controls.Add(this.fireY2);
            this.Controls.Add(this.fireY1);
            this.Controls.Add(this.fireX4);
            this.Controls.Add(this.fireX3);
            this.Controls.Add(this.fireX2);
            this.Controls.Add(this.fireX1);
            this.Controls.Add(this.fireW4);
            this.Controls.Add(this.fireW3);
            this.Controls.Add(this.fireW2);
            this.Controls.Add(this.fireW1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fireW1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireW2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireW3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireW4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireX1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireX2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireX3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireX4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireY1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireY2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireY3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireY4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireZ1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireZ2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireZ3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireZ4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireA1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireB1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireC1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireD1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireA2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireB2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireC2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireD2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireA3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireB3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireC3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireD3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireA4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireB4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireC4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fireD4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missW1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missW2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missW3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missW4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missX1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missX2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missX3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missX4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missY1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missY2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missY3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missY4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missZ1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missA3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missA2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missA1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missZ4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missZ3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missZ2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missD1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missC4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missC3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missC2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missC1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missB4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missB3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missB2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missB1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missA4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missD3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.missD2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox fireW1;
        private System.Windows.Forms.PictureBox fireW2;
        private System.Windows.Forms.PictureBox fireW3;
        private System.Windows.Forms.PictureBox fireW4;
        private System.Windows.Forms.PictureBox fireX1;
        private System.Windows.Forms.PictureBox fireX2;
        private System.Windows.Forms.PictureBox fireX3;
        private System.Windows.Forms.PictureBox fireX4;
        private System.Windows.Forms.PictureBox fireY1;
        private System.Windows.Forms.PictureBox fireY2;
        private System.Windows.Forms.PictureBox fireY3;
        private System.Windows.Forms.PictureBox fireY4;
        private System.Windows.Forms.PictureBox fireZ1;
        private System.Windows.Forms.PictureBox fireZ2;
        private System.Windows.Forms.PictureBox fireZ3;
        private System.Windows.Forms.PictureBox fireZ4;
        private System.Windows.Forms.PictureBox fireA1;
        private System.Windows.Forms.PictureBox fireB1;
        private System.Windows.Forms.PictureBox fireC1;
        private System.Windows.Forms.PictureBox fireD1;
        private System.Windows.Forms.PictureBox fireA2;
        private System.Windows.Forms.PictureBox fireB2;
        private System.Windows.Forms.PictureBox fireC2;
        private System.Windows.Forms.PictureBox fireD2;
        private System.Windows.Forms.PictureBox fireA3;
        private System.Windows.Forms.PictureBox fireB3;
        private System.Windows.Forms.PictureBox fireC3;
        private System.Windows.Forms.PictureBox fireD3;
        private System.Windows.Forms.PictureBox fireA4;
        private System.Windows.Forms.PictureBox fireB4;
        private System.Windows.Forms.PictureBox fireC4;
        private System.Windows.Forms.PictureBox fireD4;
        private System.Windows.Forms.Button w1;
        private System.Windows.Forms.Button w2;
        private System.Windows.Forms.Button W3;
        private System.Windows.Forms.Button w4;
        private System.Windows.Forms.Button x1;
        private System.Windows.Forms.Button x2;
        private System.Windows.Forms.PictureBox missW1;
        private System.Windows.Forms.PictureBox missW2;
        private System.Windows.Forms.PictureBox missW3;
        private System.Windows.Forms.PictureBox missW4;
        private System.Windows.Forms.PictureBox missX1;
        private System.Windows.Forms.PictureBox missX2;
        private System.Windows.Forms.PictureBox missX3;
        private System.Windows.Forms.PictureBox missX4;
        private System.Windows.Forms.PictureBox missY1;
        private System.Windows.Forms.PictureBox missY2;
        private System.Windows.Forms.PictureBox missY3;
        private System.Windows.Forms.PictureBox missY4;
        private System.Windows.Forms.PictureBox missZ1;
        private System.Windows.Forms.PictureBox missA3;
        private System.Windows.Forms.PictureBox missA2;
        private System.Windows.Forms.PictureBox missA1;
        private System.Windows.Forms.PictureBox missZ4;
        private System.Windows.Forms.PictureBox missZ3;
        private System.Windows.Forms.PictureBox missZ2;
        private System.Windows.Forms.Button y1;
        private System.Windows.Forms.Button x4;
        private System.Windows.Forms.Button x3;
        private System.Windows.Forms.Button y2;
        private System.Windows.Forms.Button y3;
        private System.Windows.Forms.Button y4;
        private System.Windows.Forms.Button z1;
        private System.Windows.Forms.Button z2;
        private System.Windows.Forms.Button z3;
        private System.Windows.Forms.Button z4;
        private System.Windows.Forms.Button a1;
        private System.Windows.Forms.PictureBox missD1;
        private System.Windows.Forms.PictureBox missC4;
        private System.Windows.Forms.PictureBox missC3;
        private System.Windows.Forms.PictureBox missC2;
        private System.Windows.Forms.PictureBox missC1;
        private System.Windows.Forms.PictureBox missB4;
        private System.Windows.Forms.PictureBox missB3;
        private System.Windows.Forms.PictureBox missB2;
        private System.Windows.Forms.PictureBox missB1;
        private System.Windows.Forms.PictureBox missA4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox missD3;
        private System.Windows.Forms.PictureBox missD2;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button a4;
        private System.Windows.Forms.Button a3;
        private System.Windows.Forms.Button a2;
        private System.Windows.Forms.Button c2;
        private System.Windows.Forms.Button c1;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button d3;
        private System.Windows.Forms.Button d2;
        private System.Windows.Forms.Button d1;
        private System.Windows.Forms.Button c4;
        private System.Windows.Forms.Button c3;
        private System.Windows.Forms.Button d4;
        private System.Windows.Forms.ListBox listBox1;
    }
}

