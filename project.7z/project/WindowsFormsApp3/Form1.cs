﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
     
     public partial class Form1 : Form
    {
         Player x = new Player();
        public Form1()
        {
            // Player x = new Player();
            InitializeComponent();
            if (x.Ships.Count == 4)
            {
                MessageBox.Show("success");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox30_Click(object sender, EventArgs e)
        {

        }

        private void fireD4_Click(object sender, EventArgs e)
        {
           
        }

        private void fireA3_Click(object sender, EventArgs e)
        {

        }

        private void a1_Click(object sender, EventArgs e)
        {

          
        }

        private void press(object sender, EventArgs e)
        {
            if (x.Ships.Count < 4)
            {
                
        
                x.Ships.Add((sender as Button).Text);
                (sender as Button).BackColor = Color.Blue;
                if (x.Ships.Count == 4)
                {
                    listBox1.Visible = true;
                }
                

            }
            else 
                MessageBox.Show("max number of ships");

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

           

        }
    }
}
